<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Lujos</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Maniguetas De Lujo Ktm Duke 200 Duke 250 Abatible</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/maniguetas lujo.jpg" alt=""></td>
            <td>Genérica</td>
            <td>0004555</td>
            <td>Ambos lados</td>
            <td>Aluminio</td>
            <td>135.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>