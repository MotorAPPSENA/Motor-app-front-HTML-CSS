<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Calcomanias</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Calcomanías Moto Akt Nkd 2016/ 2021 Garantía 1 Año</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/calcomanias.jpg" alt=""></td>
            <td>Genérico</td>
            <td>0041255</td>
            <td>NKD</td>
            <td>Papel autoadhesivo</td>
            <td>36.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>

    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>