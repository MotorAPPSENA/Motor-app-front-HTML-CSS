<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Frenos</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Juego Pastillas Ktm Duke 200-250-390 Bybre Original Bajaj</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/juego de pastillas.jpg" alt=""></td>
            <td>Bajaj</td>
            <td>0015051</td>
            <td>Delanteras - Traseras</td>
            <td>Carbono</td>
            <td>110.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>