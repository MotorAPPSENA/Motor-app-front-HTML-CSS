<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Accesorios</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Llanta trasero para moto Pirelli Sport Diablo Rosso III sin cámara de 150/60R17 H 66 x 1 unidad</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/llanta pirelli.jpg" alt=""></td>
            <td>Pirelli</td>
            <td>00142005</td>
            <td>Trasero,Índice de carga 66, Modelo, Diablo Rosso III,</td>
            <td>Tamaño 150/60R17, Ancho de sección 150 mm, Perfil 60 Diámetro de la llanta 17 ", Tipo de adherencia
                Seco, Mojado</td>
            <td>505.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>