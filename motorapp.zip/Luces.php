<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Luces</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Exploradoras Turbo Led Antiniebla Bicolor 20000lm Carro/moto</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/exploradorasmoto.jpg" alt=""></td>
            <td>TURBO LED</td>
            <td>0001105</td>
            <td>3 Cables</td>
            <td>4 LEDS - 20000 lm</td>
            <td>162.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>