<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Motor</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Kit De Juntas De Pistón De Cilindro Para Honda Foreman 450 T.jpg"
                    alt=""></td>
            <td>Sinocmp</td>
            <td>00000425</td>
            <td>Número de pieza 450 TRX450, Modelo Cylinders</td>
            <td>Diámetro del cilindro 90 mm - Incluye pistones Sí - Incluye aros Sí</td>
            <td>779.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>