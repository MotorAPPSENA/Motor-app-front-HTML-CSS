<?php require ('Apartados/Paginas/apartadoadmin.php') ?>
<link rel="stylesheet" href="Estilo Apartados/productos.css">

<div class="titulo">
    <h1>Listado de Productos</h1>
    <button class="BotonTitulo">Nuevo producto</button>
</div>
</body>

</html>