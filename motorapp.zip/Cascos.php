<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Cascos</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Casco Spartan Wolf Ds</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/cascosparta.jpg" alt=""></td>
            <td>Spartan</td>
            <td>0000455</td>
            <td>Normas de seguridad -ECE22.05 -Wolf DS</td>
            <td>Interior: Interior desmotable y lavable,Interior fabricado con tejidos antialergénicos Exterior: Calota
                de policarbonato moldeado de alto impacto</td>
            <td>465.900$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>

    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>