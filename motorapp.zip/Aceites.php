<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">

<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->

<table>
    <caption>Lubricantes</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Aceite Moto 4t 7100 10w30 100% Sintetico Motul 1l</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/Aceitemotul.jpg" alt=""></td>
            <td>Motul</td>
            <td>00054555</td>
            <td>Botella</td>
            <td>Sintético</td>
            <td>63.500$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>