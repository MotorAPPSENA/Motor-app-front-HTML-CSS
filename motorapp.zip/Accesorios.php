<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">

<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->

<table>
    <caption>Accesorios</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Guantes Para Moto Impermeables Térmicos Táctiles Protección</td>
            <td> <img class="tamañoImgPedidos" src="Imagenes/Imagenes Productos/producto guantes.jpg" alt=""></td>
            <td>Vemar</td>
            <td>0001455</td>
            <td>Impermeables,Termicos,Táctiles</td>
            <td>Nylon,Polyester</td>
            <td>129.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
<!-- Aqui comienza nuestro pie de pagina-->
<?php require('Apartados/Paginas/piePagina.php')?>