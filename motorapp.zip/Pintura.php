<?php require ('Apartados/Paginas/BarraNavegacion.php') ?>
<link rel="stylesheet" href="Estilo Apartados/StyleTablas.css">
<!-- Aqui finaliza nuestra barra de navagacion responsive-->
<!-- Tabla Aceites-->
<table>
    <caption>Pintura</caption>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Marca</th>
            <th>Referencia</th>
            <th>Tipo</th>
            <th>Material</th>
            <th>Precio</th>
            <th>Stock Disponible</th>
            <th>Accion</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>
        <tr>
            <td>Pintura De Fibra De Carbono Para Carenado De Radiador Para</td>
            <td> <img class="tamañoImgPedidos"
                    src="Imagenes/Imagenes Productos/Pintura De Fibra De Carbono Para Carenado De Radiador Para.jpg"
                    alt=""></td>
            <td>Genérica</td>
            <td>0015010</td>
            <td>autoclave o proceso de moldeo a presión, material ABS de alta calidad,</td>
            <td>Fibra de carbono</td>
            <td>368.000$</td>
            <td>100</td>
            <td><button>Agregar al carrito</button></td>
        </tr>


    </tbody>
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th>5.000.000</th>
            <th>5000</th>
        </tr>
    </tfoot>

</table>
</body>

</html>