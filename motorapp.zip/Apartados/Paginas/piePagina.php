<!-- Aqui comienza nuestro pie de pagina-->
<footer class="footernav" >
			<ul class="listfoot">
				<a href="./terminosCondiciones.php" target="blank" rel="noopener noreferrer">
					<li>Terminos de Uso y Politica de privacidad</li>
				</a>
				<li>
					<div class="redesSociales">
						<a href="https://www.facebook.com/" target="blank" rel="noopener noreferrer" >  <img src="Imagenes/Logofacebook.jpeg" alt=""></a>
						<a href="https://wa.me/573014200329?text=Me%20interesan%20tus%20Productos" target="blank" rel="noopener noreferrer" > <img src="Imagenes/whatsapplogo.png" alt=""></a>
						<a href="https://www.tiktok.com/es/" target="blank" rel="noopener noreferrer"> <img src="Imagenes/logotiktok.png" alt=""></a>
						<a href="https://www.youtube.com/channel/UCgmhgjSNCrnMrduUFJCcLyg" target="blank" rel="noopener noreferrer"> <img src="Imagenes/youtubelogo.png" alt=""></a>
					</div>
				</li>
			</ul>
	</footer>


</body>

</html>